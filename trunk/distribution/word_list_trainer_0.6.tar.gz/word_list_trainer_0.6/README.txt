
WORD LIST TRAINER

This is a program that is made for language learning and that makes it easy to create and share word lists with the source language in one column and the language that shall be learned in the other as well as recording and attaching sounds to every word. 

REQUIREMENTS
The application require Java 1.6. It can be downloaded from www.java.com

INSTALLATION

1. Open a terminal (In windows you can type cmd in the run dialog which can be found in the start menu)
2. Change the current directory to the bin directory (cd /path_to_the_unzipped_folder/bin)
3. Type java -jar word_list_trainer_VERSION.jar.

On most system it is possible to run the application just by double clicking on the file word_list_trainer_VERSION.jar in the bin directory if sun's java is installed.

Alternatively the application can be installed with the Java Web Start installer that is available at http://wordlisttrainer.googlecode.com/.

PROJECT INFO

Any questions or suggestions can be reported at the home page http://wordlisttrainer.googlecode.com or sent to kjellwinblad@gmail.com. The project is currently looking for more developers.